Used node 16.13.2
To run the application, you need to install packages 
```npm install``
To start a local server
```npm run start```
To build a project
```npm run build```